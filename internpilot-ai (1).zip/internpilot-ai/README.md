# InternPilot AI

AI-powered internship management platform. Students discover and apply to internships, track applications, get AI recommendations, analyse resumes, close skill gaps, and prepare for interviews. Providers post internships and manage applicants. Admins oversee users and platform activity.

**Stack:** React (Vite) + Tailwind CSS · Node.js + Express · MongoDB (Mongoose) · JWT auth · OpenAI API · Nodemailer

---

## 1. Project structure

```
internpilot-ai/
├── server/                     # Express REST API
│   ├── .env.example            # copy to .env and fill in
│   ├── package.json
│   └── src/
│       ├── server.js           # entry point (connects DB, starts server)
│       ├── app.js              # Express setup (helmet, cors, routes, errors)
│       ├── seed.js             # sample accounts and internships
│       ├── config/             # env loading, MongoDB connection
│       ├── models/             # User, Internship, Application, Notification
│       ├── middleware/         # JWT auth + role checks, validation, error handler
│       ├── controllers/        # request handlers per module
│       ├── routes/             # URL → controller mapping with validation rules
│       ├── services/           # AI service, email, notifications
│       └── utils/              # AppError, helpers
└── client/                     # React frontend
    ├── index.html
    ├── vite.config.js          # dev proxy /api → localhost:5000
    ├── tailwind.config.js
    └── src/
        ├── App.jsx             # routes with role protection
        ├── api/client.js       # axios instance + JWT header + error helper
        ├── context/AuthContext.jsx
        ├── components/         # Layout, Navbar, ProtectedRoute, StatusBadge
        └── pages/              # Landing, Login, Register, dashboards, AI tools...
```

---

## 2. Prerequisites

1. **Node.js 18 or newer**: https://nodejs.org (choose the LTS version).
2. **MongoDB**, either:
   - **Local:** install MongoDB Community Server, or
   - **Cloud (recommended for beginners):** create a free cluster at MongoDB Atlas and copy its connection string.
3. **VS Code** with the ESLint and Tailwind CSS IntelliSense extensions (optional but helpful).

---

## 3. Setup (step by step)

Open the project folder in VS Code, then open two terminals.

### Terminal 1: backend

```bash
cd server
npm install
cp .env.example .env          # Windows PowerShell: copy .env.example .env
```

Open `server/.env` and set at least:

```env
MONGODB_URI=mongodb://127.0.0.1:27017/internpilot   # or your Atlas connection string
JWT_SECRET=paste_a_long_random_string_here           # e.g. run: node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Then seed sample data and start the API:

```bash
npm run seed
npm run dev
```

The API runs on http://localhost:5000. Check http://localhost:5000/api/health.

### Terminal 2: frontend

```bash
cd client
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

### Sample accounts (created by `npm run seed`)

| Role     | Email                          | Password                              |
|----------|--------------------------------|---------------------------------------|
| Admin    | admin@internpilot.local        | `SEED_PASSWORD` (default `ChangeMe@123`) |
| Provider | provider@internpilot.local     | same                                  |
| Student  | student@internpilot.local      | same                                  |

Change `SEED_PASSWORD` before seeding if you want your own password. Seeding only runs on an empty database.

---

## 4. Features that need external credentials

The app runs without these, but the features below behave differently until you configure them.

| Feature | What you need | Without it |
|---------|---------------|------------|
| AI recommendations, resume analysis, skill gap plans, interview questions, chatbot | `OPENAI_API_KEY` from https://platform.openai.com/api-keys | Rule-based fallbacks run for recommendations, resume, skill gap and interview prep. The chatbot shows a setup message. |
| Chatbot in Tamil | `OPENAI_API_KEY` (answer quality depends on the model) | Same as above |
| Email notifications | SMTP credentials. For Gmail: enable 2-Step Verification, create an **App Password** at https://myaccount.google.com/apppasswords, and set `SMTP_USER` and `SMTP_PASS` | Emails are skipped and logged to the console. In-app notifications still work. |
| Cloud database | MongoDB Atlas connection string | Uses local MongoDB |

Never put these keys in the frontend code or commit `server/.env` to GitHub. `.gitignore` already excludes it.

---

## 5. API reference (summary)

All endpoints are prefixed with `/api`. Protected routes need the header `Authorization: Bearer <token>`.

| Method | Endpoint | Access | Purpose |
|--------|----------|--------|---------|
| POST | `/auth/register` | Public | Register a student or provider |
| POST | `/auth/login` | Public | Login, returns JWT |
| GET | `/auth/me` | Logged in | Current user |
| GET / PUT | `/users/profile` | Logged in | View / update profile |
| GET | `/internships` | Public | List with `q, category, location, mode, skill, minStipend, sort, page, limit` |
| GET | `/internships/:id` | Public | Internship details |
| GET | `/internships/mine` | Provider, Admin | Own internships with applicant counts |
| POST | `/internships` | Provider, Admin | Create |
| PUT / DELETE | `/internships/:id` | Owner or Admin | Update / delete |
| POST | `/applications` | Student | Apply (sends emails) |
| GET | `/applications/mine` | Student | My applications |
| GET | `/applications/internship/:internshipId` | Owner or Admin | Applicants |
| PATCH | `/applications/:id/status` | Owner or Admin | Update status (notifies student) |
| PATCH | `/applications/:id/withdraw` | Student | Withdraw |
| GET | `/notifications` | Logged in | In-app notifications |
| PATCH | `/notifications/:id/read`, `/read-all` | Logged in | Mark read |
| GET | `/admin/stats` | Admin | Platform statistics |
| GET | `/admin/users` | Admin | Search and paginate users |
| PATCH | `/admin/users/:id/status` | Admin | Enable / disable a user |
| GET | `/admin/applications` | Admin | Recent applications |
| GET | `/ai/status` | Logged in | Whether OpenAI is configured |
| GET | `/ai/recommendations` | Logged in | Ranked internship matches |
| POST | `/ai/resume/analyze` | Logged in | Analyse and store resume text |
| POST | `/ai/skill-gap` | Logged in | Skill gap and learning plan |
| POST | `/ai/interview-prep` | Logged in | Role-specific interview questions |
| POST | `/ai/chat` | Logged in | Bilingual chatbot (`language`: `en` or `ta`) |

---

## 6. Security notes

- Passwords are hashed with bcrypt (cost 12) and never returned by the API.
- JWTs are signed with `JWT_SECRET`. Use a long random value in production.
- Role-based access control is enforced on the server, not only in the UI.
- Input is validated with express-validator and Mongoose schemas. Helmet sets secure HTTP headers.
- API keys and SMTP passwords live only in `server/.env` and are read via `process.env`.

---

## 7. Known limitations

- Resume upload accepts pasted text. PDF/DOCX parsing needs an extra library such as `pdf-parse` or `mammoth`, which can be added in `aiController.js`.
- Rate limiting is not enabled on AI or auth endpoints. Add `express-rate-limit` before production.
- Tamil answer quality depends on the OpenAI model you select.
- Provider accounts are active immediately. Add an approval step if you need vetting.

---

## 8. Push to GitHub

```bash
cd internpilot-ai
git init
git add .
git commit -m "Initial commit: InternPilot AI"
git branch -M main
git remote add origin https://github.com/<your-username>/internpilot-ai.git
git push -u origin main
```

Before pushing, confirm `server/.env` is not listed by `git status`.

---

## 9. Deployment

**Database:** MongoDB Atlas → create a cluster → Database Access (user) → Network Access (allow `0.0.0.0/0` for testing) → copy the connection string.

**Backend (Render, Railway or similar):**
1. Create a new Web Service from your GitHub repo, with root directory `server`.
2. Build command: `npm install`. Start command: `npm start`.
3. Add environment variables: `MONGODB_URI`, `JWT_SECRET`, `CLIENT_URL` (your frontend URL), `OPENAI_API_KEY`, `SMTP_*`, `EMAIL_FROM`. Do not commit them.
4. Note the public URL, for example `https://internpilot-api.onrender.com`.

**Frontend (Vercel or Netlify):**
1. Import the repo with root directory `client`. Build command `npm run build`, output directory `dist`.
2. Add environment variable `VITE_API_URL=https://internpilot-api.onrender.com`.
3. Deploy. `vercel.json` handles React route refreshes.
4. Set the backend `CLIENT_URL` to your frontend URL and redeploy the backend.

---

## 10. Troubleshooting

| Problem | Fix |
|---------|-----|
| `Missing JWT_SECRET` on start | Create `server/.env` from `.env.example` |
| `MongooseServerSelectionError` | Start local MongoDB, or check the Atlas connection string and IP allow-list |
| Frontend shows network errors | Make sure the backend is running on port 5000 |
| `port already in use` | Change `PORT` in `server/.env` and the proxy target in `client/vite.config.js` |
| No emails arrive | Check SMTP values and look in the server console for `[email skipped]` |
| AI features show "Rule-based" | Add `OPENAI_API_KEY` to `server/.env` and restart the server |
