import axios from 'axios';

export const TOKEN_KEY = 'internpilot_token';

// In development the Vite proxy handles /api. In production set VITE_API_URL to your backend URL.
const api = axios.create({
  baseURL: `${import.meta.env.VITE_API_URL || ''}/api`,
  timeout: 30000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const isAuthCall = error.config?.url?.startsWith('/auth/');
    if (error.response?.status === 401 && !isAuthCall) {
      localStorage.removeItem(TOKEN_KEY);
      if (window.location.pathname !== '/login') window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const getErrorMessage = (err) =>
  err.response?.data?.details?.[0]?.message ||
  err.response?.data?.message ||
  err.message ||
  'Something went wrong. Please try again.';

export default api;
