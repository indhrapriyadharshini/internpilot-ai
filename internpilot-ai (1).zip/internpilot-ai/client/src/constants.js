// Application statuses a provider can set (withdrawn is set by the student).
export const APPLICATION_STATUS_OPTIONS = [
  'applied',
  'under_review',
  'shortlisted',
  'interview',
  'accepted',
  'rejected',
];
