import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import { useAuth } from './context/AuthContext.jsx';
import Landing from './pages/Landing.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Internships from './pages/Internships.jsx';
import InternshipDetail from './pages/InternshipDetail.jsx';
import StudentDashboard from './pages/StudentDashboard.jsx';
import MyApplications from './pages/MyApplications.jsx';
import Recommendations from './pages/Recommendations.jsx';
import ResumeAnalyzer from './pages/ResumeAnalyzer.jsx';
import SkillGap from './pages/SkillGap.jsx';
import InterviewPrep from './pages/InterviewPrep.jsx';
import Profile from './pages/Profile.jsx';
import Chatbot from './pages/Chatbot.jsx';
import Notifications from './pages/Notifications.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import ProviderDashboard from './pages/ProviderDashboard.jsx';
import NotFound from './pages/NotFound.jsx';

// /dashboard sends each role to its own home.
function DashboardHome() {
  const { user } = useAuth();
  if (user.role === 'admin') return <Navigate to="/admin" replace />;
  if (user.role === 'provider') return <Navigate to="/provider" replace />;
  return <StudentDashboard />;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/internships" element={<Internships />} />
        <Route path="/internships/:id" element={<InternshipDetail />} />

        <Route path="/dashboard" element={<ProtectedRoute><DashboardHome /></ProtectedRoute>} />
        <Route path="/applications" element={<ProtectedRoute roles={['student']}><MyApplications /></ProtectedRoute>} />
        <Route path="/recommendations" element={<ProtectedRoute roles={['student']}><Recommendations /></ProtectedRoute>} />
        <Route path="/resume" element={<ProtectedRoute roles={['student']}><ResumeAnalyzer /></ProtectedRoute>} />
        <Route path="/skill-gap" element={<ProtectedRoute roles={['student']}><SkillGap /></ProtectedRoute>} />
        <Route path="/interview-prep" element={<ProtectedRoute roles={['student']}><InterviewPrep /></ProtectedRoute>} />
        <Route path="/provider" element={<ProtectedRoute roles={['provider']}><ProviderDashboard /></ProtectedRoute>} />
        <Route path="/admin" element={<ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>} />

        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/chatbot" element={<ProtectedRoute><Chatbot /></ProtectedRoute>} />
        <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
