import { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import api from '../api/client.js';

const NAV = {
  student: [
    ['Dashboard', '/dashboard'],
    ['Internships', '/internships'],
    ['My Applications', '/applications'],
    ['Recommendations', '/recommendations'],
    ['Resume AI', '/resume'],
    ['Skill Gap', '/skill-gap'],
    ['Interview Prep', '/interview-prep'],
    ['Chatbot', '/chatbot'],
  ],
  provider: [
    ['Provider Panel', '/provider'],
    ['Internships', '/internships'],
    ['Chatbot', '/chatbot'],
  ],
  admin: [
    ['Admin Panel', '/admin'],
    ['Internships', '/internships'],
    ['Chatbot', '/chatbot'],
  ],
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) {
      setUnread(0);
      return;
    }
    api.get('/notifications').then((r) => setUnread(r.data.unread)).catch(() => {});
  }, [user]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const links = user ? NAV[user.role] || [] : [['Browse Internships', '/internships']];

  return (
    <header className="sticky top-0 z-10 border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="text-lg font-bold text-indigo-700">InternPilot AI</Link>

        <nav className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
          {links.map(([label, to]) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                isActive ? 'font-semibold text-indigo-700' : 'text-slate-600 hover:text-indigo-600'
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3 text-sm">
          {user ? (
            <>
              <Link to="/notifications" className="relative text-slate-600 hover:text-indigo-600">
                Alerts
                {unread > 0 && (
                  <span className="ml-1 rounded-full bg-red-500 px-1.5 text-xs text-white">{unread}</span>
                )}
              </Link>
              <Link to="/profile" className="text-slate-600 hover:text-indigo-600">{user.name}</Link>
              <button onClick={handleLogout} className="btn-outline">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-slate-600 hover:text-indigo-600">Login</Link>
              <Link to="/register" className="btn-primary">Register</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
