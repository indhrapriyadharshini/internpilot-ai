import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const toText = (list) => (Array.isArray(list) ? list.join(', ') : '');
const toList = (text) => text.split(',').map((s) => s.trim()).filter(Boolean);

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState(null);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const p = user.profile || {};
    setForm({
      name: user.name || '',
      company: user.company || '',
      phone: p.phone || '',
      college: p.college || '',
      degree: p.degree || '',
      graduationYear: p.graduationYear || '',
      skills: toText(p.skills),
      interests: toText(p.interests),
      preferredLocations: toText(p.preferredLocations),
      bio: p.bio || '',
      linkedin: p.linkedin || '',
      portfolio: p.portfolio || '',
    });
  }, [user]);

  if (!form) return null;
  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    setMessage({ type: '', text: '' });
    const payload = {
      name: form.name,
      company: form.company,
      profile: {
        phone: form.phone,
        college: form.college,
        degree: form.degree,
        graduationYear: form.graduationYear ? Number(form.graduationYear) : undefined,
        skills: toList(form.skills),
        interests: toList(form.interests),
        preferredLocations: toList(form.preferredLocations),
        bio: form.bio,
        linkedin: form.linkedin,
        portfolio: form.portfolio,
      },
    };
    try {
      const { data } = await api.put('/users/profile', payload);
      updateUser(data.user);
      setMessage({ type: 'ok', text: 'Profile saved successfully.' });
    } catch (err) {
      setMessage({ type: 'err', text: getErrorMessage(err) });
    } finally {
      setBusy(false);
    }
  };

  const isStudent = user.role === 'student';

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-6 text-2xl font-bold">My profile</h1>
      <form onSubmit={save} className="card grid gap-4 md:grid-cols-2">
        <div>
          <label className="label">Full name</label>
          <input className="input" value={form.name} onChange={set('name')} />
        </div>
        <div>
          <label className="label">Email</label>
          <input className="input bg-slate-100" value={user.email} disabled />
        </div>
        {user.role === 'provider' && (
          <div className="md:col-span-2">
            <label className="label">Company</label>
            <input className="input" value={form.company} onChange={set('company')} />
          </div>
        )}
        {isStudent && (
          <>
            <div>
              <label className="label">Phone</label>
              <input className="input" value={form.phone} onChange={set('phone')} />
            </div>
            <div>
              <label className="label">College</label>
              <input className="input" value={form.college} onChange={set('college')} />
            </div>
            <div>
              <label className="label">Degree</label>
              <input className="input" value={form.degree} onChange={set('degree')} />
            </div>
            <div>
              <label className="label">Graduation year</label>
              <input type="number" min="2000" max="2100" className="input" value={form.graduationYear} onChange={set('graduationYear')} />
            </div>
            <div className="md:col-span-2">
              <label className="label">Skills (comma separated)</label>
              <input className="input" placeholder="javascript, react, sql" value={form.skills} onChange={set('skills')} />
              <p className="mt-1 text-xs text-slate-500">These drive recommendations and skill gap analysis.</p>
            </div>
            <div className="md:col-span-2">
              <label className="label">Interests (comma separated)</label>
              <input className="input" placeholder="web development, data science" value={form.interests} onChange={set('interests')} />
            </div>
            <div className="md:col-span-2">
              <label className="label">Preferred locations (comma separated)</label>
              <input className="input" placeholder="Chennai, Remote" value={form.preferredLocations} onChange={set('preferredLocations')} />
            </div>
            <div className="md:col-span-2">
              <label className="label">Bio</label>
              <textarea rows={3} maxLength={1000} className="input" value={form.bio} onChange={set('bio')} />
            </div>
            <div>
              <label className="label">LinkedIn URL</label>
              <input className="input" value={form.linkedin} onChange={set('linkedin')} />
            </div>
            <div>
              <label className="label">Portfolio URL</label>
              <input className="input" value={form.portfolio} onChange={set('portfolio')} />
            </div>
          </>
        )}
        <div className="md:col-span-2 flex items-center gap-4">
          <button disabled={busy} className="btn-primary">{busy ? 'Saving...' : 'Save profile'}</button>
          {message.text && <span className={message.type === 'ok' ? 'text-green-700' : 'text-red-600'}>{message.text}</span>}
        </div>
      </form>
    </div>
  );
}
