import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';

export default function Notifications() {
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [error, setError] = useState('');

  const load = () =>
    api
      .get('/notifications')
      .then((r) => { setItems(r.data.data); setUnread(r.data.unread); })
      .catch((err) => setError(getErrorMessage(err)));

  useEffect(() => { load(); }, []);

  const markRead = async (id) => {
    await api.patch(`/notifications/${id}/read`).catch(() => {});
    load();
  };

  const markAll = async () => {
    await api.patch('/notifications/read-all').catch(() => {});
    load();
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notifications <span className="text-base text-slate-500">({unread} unread)</span></h1>
        {unread > 0 && <button className="btn-outline" onClick={markAll}>Mark all as read</button>}
      </div>
      {error && <p className="text-red-600">{error}</p>}
      {items.length === 0 ? (
        <p className="text-slate-500">No notifications yet.</p>
      ) : (
        <div className="space-y-3">
          {items.map((n) => (
            <div key={n._id} className={`card flex items-start justify-between gap-4 ${n.read ? '' : 'border-indigo-300 bg-indigo-50/40'}`}>
              <div>
                <h3 className="font-semibold">{n.title}</h3>
                <p className="text-sm text-slate-700">{n.message}</p>
                <p className="mt-1 text-xs text-slate-500">{new Date(n.createdAt).toLocaleString()}</p>
              </div>
              {!n.read && <button className="btn-outline shrink-0" onClick={() => markRead(n._id)}>Mark read</button>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
