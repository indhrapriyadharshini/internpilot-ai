import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { getErrorMessage } from '../api/client.js';

const EMPTY = { name: '', email: '', password: '', role: 'student', company: '' };

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await register(form);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setError(getErrorMessage(err));
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-2xl font-bold">Create your account</h1>
        {error && <p className="rounded bg-red-50 p-3 text-sm text-red-700">{error}</p>}
        <div>
          <label className="label">I am a</label>
          <select className="input" value={form.role} onChange={set('role')}>
            <option value="student">Student looking for internships</option>
            <option value="provider">Internship provider (company)</option>
          </select>
        </div>
        <div>
          <label className="label">Full name</label>
          <input required minLength={2} className="input" value={form.name} onChange={set('name')} />
        </div>
        {form.role === 'provider' && (
          <div>
            <label className="label">Company name</label>
            <input required className="input" value={form.company} onChange={set('company')} />
          </div>
        )}
        <div>
          <label className="label">Email</label>
          <input type="email" required className="input" value={form.email} onChange={set('email')} />
        </div>
        <div>
          <label className="label">Password (min 6 characters)</label>
          <input type="password" required minLength={6} className="input" value={form.password} onChange={set('password')} />
        </div>
        <button disabled={busy} className="btn-primary w-full">{busy ? 'Creating account...' : 'Create account'}</button>
        <p className="text-center text-sm text-slate-600">
          Already registered? <Link to="/login" className="text-indigo-600">Login</Link>
        </p>
      </form>
    </div>
  );
}
