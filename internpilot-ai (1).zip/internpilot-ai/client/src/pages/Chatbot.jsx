import { useEffect, useRef, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';

const GREETING = {
  role: 'assistant',
  content: 'Hi! I am InternPilot AI. Ask me about internships, applications, resumes or interviews.\n\nவணக்கம்! இன்டர்ன்ஷிப், விண்ணப்பங்கள், ரெஸ்யூம் அல்லது நேர்காணல் பற்றி தமிழில் கேட்கலாம்.',
};

export default function Chatbot() {
  const [messages, setMessages] = useState([GREETING]);
  const [input, setInput] = useState('');
  const [language, setLanguage] = useState('en');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const send = async (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;

    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setInput('');
    setLoading(true);
    setError('');
    try {
      const { data } = await api.post('/ai/chat', { messages: next.slice(-20), language });
      setMessages([...next, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex max-w-3xl flex-col">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">InternPilot chatbot</h1>
        <select className="input w-auto" value={language} onChange={(e) => setLanguage(e.target.value)} aria-label="Reply language">
          <option value="en">English</option>
          <option value="ta">தமிழ் (Tamil)</option>
        </select>
      </div>

      <div className="card flex h-[60vh] flex-col gap-3 overflow-y-auto">
        {messages.map((m, i) => (
          <div key={i} className={`max-w-[80%] whitespace-pre-line rounded-2xl px-4 py-2 text-sm ${m.role === 'user' ? 'ml-auto bg-indigo-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
            {m.content}
          </div>
        ))}
        {loading && <div className="text-sm text-slate-500">InternPilot is typing...</div>}
        <div ref={bottomRef} />
      </div>

      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
      <form onSubmit={send} className="mt-3 flex gap-2">
        <input className="input" placeholder={language === 'ta' ? 'உங்கள் கேள்வியை எழுதுங்கள்...' : 'Type your question...'} value={input} onChange={(e) => setInput(e.target.value)} maxLength={2000} />
        <button disabled={loading || !input.trim()} className="btn-primary">Send</button>
      </form>
    </div>
  );
}
