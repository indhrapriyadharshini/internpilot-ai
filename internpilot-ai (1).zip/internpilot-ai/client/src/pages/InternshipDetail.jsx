import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api, { getErrorMessage } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function InternshipDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [item, setItem] = useState(null);
  const [applied, setApplied] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/internships/${id}`).then((r) => setItem(r.data.data)).catch((err) => setError(getErrorMessage(err)));
  }, [id]);

  useEffect(() => {
    if (user?.role !== 'student') return;
    api
      .get('/applications/mine')
      .then((r) => setApplied(r.data.data.some((a) => a.internship?._id === id)))
      .catch(() => {});
  }, [id, user]);

  const apply = async (e) => {
    e.preventDefault();
    setBusy(true);
    setMessage({ type: '', text: '' });
    try {
      await api.post('/applications', { internshipId: id, coverLetter });
      setApplied(true);
      setMessage({ type: 'ok', text: 'Application submitted! A confirmation email is on its way.' });
    } catch (err) {
      setMessage({ type: 'err', text: getErrorMessage(err) });
    } finally {
      setBusy(false);
    }
  };

  if (error) return <p className="text-red-600">{error}</p>;
  if (!item) return <p className="text-slate-500">Loading...</p>;

  const deadlinePassed = item.deadline && new Date(item.deadline) < new Date();

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="card space-y-5 md:col-span-2">
        <div>
          <h1 className="text-2xl font-bold">{item.title}</h1>
          <p className="text-slate-600">{item.company} · {item.location || 'Flexible'} · {item.mode} · {item.duration || 'Duration flexible'}</p>
        </div>
        <section>
          <h2 className="mb-1 font-semibold">About the role</h2>
          <p className="whitespace-pre-line text-slate-700">{item.description}</p>
        </section>
        {item.requirements?.length > 0 && (
          <section>
            <h2 className="mb-1 font-semibold">Requirements</h2>
            <ul className="list-disc pl-5 text-slate-700">
              {item.requirements.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </section>
        )}
        <section>
          <h2 className="mb-2 font-semibold">Skills</h2>
          <div className="flex flex-wrap gap-2">
            {item.skills.map((s) => (
              <span key={s} className="rounded bg-indigo-50 px-2 py-1 text-sm text-indigo-700">{s}</span>
            ))}
          </div>
        </section>
      </div>

      <aside className="card h-fit space-y-3">
        <p><b>Stipend:</b> {item.stipend ? `₹${item.stipend.toLocaleString('en-IN')}/month` : 'Not specified'}</p>
        <p><b>Openings:</b> {item.openings}</p>
        <p><b>Deadline:</b> {item.deadline ? new Date(item.deadline).toLocaleDateString() : 'Open'}</p>
        <p><b>Category:</b> {item.category}</p>

        {message.text && <p className={message.type === 'ok' ? 'text-green-700' : 'text-red-600'}>{message.text}</p>}

        {!user && <Link to="/login" state={{ from: `/internships/${id}` }} className="btn-primary w-full">Login to apply</Link>}
        {user?.role !== 'student' && user && <p className="text-sm text-slate-500">Only students can apply to internships.</p>}
        {user?.role === 'student' && (
          applied ? (
            <p className="font-medium text-green-700">You have already applied to this internship.</p>
          ) : deadlinePassed ? (
            <p className="text-red-600">The application deadline has passed.</p>
          ) : (
            <form onSubmit={apply} className="space-y-2">
              <label className="label" htmlFor="cover">Cover letter (optional)</label>
              <textarea id="cover" rows={5} maxLength={2000} className="input" value={coverLetter} onChange={(e) => setCoverLetter(e.target.value)} />
              <button disabled={busy} className="btn-primary w-full">{busy ? 'Submitting...' : 'Apply now'}</button>
            </form>
          )
        )}
      </aside>
    </div>
  );
}
