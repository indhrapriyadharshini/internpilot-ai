import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';
import StatusBadge from '../components/StatusBadge.jsx';
import { APPLICATION_STATUS_OPTIONS } from '../constants.js';

const EMPTY_FORM = {
  title: '', description: '', category: '', location: '', mode: 'onsite',
  duration: '', stipend: '', openings: 1, deadline: '', skills: '',
};

export default function ProviderDashboard() {
  const [internships, setInternships] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [selected, setSelected] = useState(null);
  const [applicants, setApplicants] = useState([]);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const loadInternships = () =>
    api.get('/internships/mine').then((r) => setInternships(r.data.data)).catch((err) => setError(getErrorMessage(err)));

  useEffect(() => { loadInternships(); }, []);

  const createInternship = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await api.post('/internships', {
        ...form,
        stipend: Number(form.stipend) || 0,
        openings: Number(form.openings) || 1,
        deadline: form.deadline || undefined,
        skills: form.skills.split(',').map((s) => s.trim()).filter(Boolean),
      });
      setForm(EMPTY_FORM);
      setNotice('Internship published.');
      loadInternships();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const toggleActive = async (item) => {
    try {
      await api.put(`/internships/${item._id}`, { isActive: !item.isActive });
      loadInternships();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const removeInternship = async (item) => {
    if (!window.confirm(`Delete "${item.title}" and all its applications?`)) return;
    try {
      await api.delete(`/internships/${item._id}`);
      if (selected?._id === item._id) setSelected(null);
      loadInternships();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const viewApplicants = async (item) => {
    setSelected(item);
    setError('');
    try {
      const { data } = await api.get(`/applications/internship/${item._id}`);
      setApplicants(data.data);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const updateStatus = async (appId, status) => {
    try {
      await api.patch(`/applications/${appId}/status`, { status, note: '' });
      viewApplicants(selected);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Provider dashboard</h1>
      {error && <p className="text-red-600">{error}</p>}
      {notice && <p className="text-green-700">{notice}</p>}

      <form onSubmit={createInternship} className="card grid gap-4 md:grid-cols-2">
        <h2 className="font-semibold md:col-span-2">Post a new internship</h2>
        <input required className="input" placeholder="Job title" value={form.title} onChange={set('title')} />
        <input className="input" placeholder="Category (e.g. Web Development)" value={form.category} onChange={set('category')} />
        <textarea required rows={4} minLength={30} className="input md:col-span-2" placeholder="Describe the role (min 30 characters)" value={form.description} onChange={set('description')} />
        <input className="input" placeholder="Location" value={form.location} onChange={set('location')} />
        <select className="input" value={form.mode} onChange={set('mode')}>
          <option value="onsite">On-site</option>
          <option value="remote">Remote</option>
          <option value="hybrid">Hybrid</option>
        </select>
        <input className="input" placeholder="Duration (e.g. 3 months)" value={form.duration} onChange={set('duration')} />
        <input className="input" type="number" min="0" placeholder="Stipend per month (₹)" value={form.stipend} onChange={set('stipend')} />
        <input className="input" type="number" min="1" placeholder="Openings" value={form.openings} onChange={set('openings')} />
        <input className="input" type="date" aria-label="Application deadline" value={form.deadline} onChange={set('deadline')} />
        <input className="input md:col-span-2" placeholder="Required skills, comma separated (e.g. react, sql)" value={form.skills} onChange={set('skills')} />
        <button disabled={busy} className="btn-primary md:col-span-2 md:w-fit">{busy ? 'Publishing...' : 'Publish internship'}</button>
      </form>

      <div className="card">
        <h2 className="mb-4 font-semibold">Your internships</h2>
        {internships.length === 0 ? (
          <p className="text-slate-500">You have not posted any internships yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b text-slate-500">
                <tr><th className="py-2">Title</th><th>Mode</th><th>Applicants</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {internships.map((i) => (
                  <tr key={i._id} className="border-b last:border-0">
                    <td className="py-2 font-medium">{i.title}</td>
                    <td className="capitalize">{i.mode}</td>
                    <td>{i.applicantCount}</td>
                    <td>{i.isActive ? <span className="text-green-700">Open</span> : <span className="text-slate-500">Closed</span>}</td>
                    <td className="space-x-2 whitespace-nowrap">
                      <button className="btn-outline" onClick={() => viewApplicants(i)}>Applicants</button>
                      <button className="btn-outline" onClick={() => toggleActive(i)}>{i.isActive ? 'Close' : 'Reopen'}</button>
                      <button className="btn-outline text-red-600" onClick={() => removeInternship(i)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selected && (
        <div className="card">
          <h2 className="mb-4 font-semibold">Applicants for {selected.title}</h2>
          {applicants.length === 0 ? (
            <p className="text-slate-500">No applicants yet.</p>
          ) : (
            <div className="space-y-4">
              {applicants.map((a) => (
                <div key={a._id} className="rounded-lg border border-slate-200 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold">{a.student?.name} <span className="text-sm font-normal text-slate-500">{a.student?.email}</span></p>
                      <p className="text-sm text-slate-600">{a.student?.profile?.degree} · {a.student?.profile?.college} {a.student?.profile?.graduationYear ? `(${a.student.profile.graduationYear})` : ''}</p>
                      <p className="mt-1 text-sm">Skills: {a.student?.profile?.skills?.join(', ') || 'not listed'}</p>
                      {a.coverLetter && <p className="mt-2 whitespace-pre-line rounded bg-slate-50 p-2 text-sm">{a.coverLetter}</p>}
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge status={a.status} />
                      <select className="input w-auto" value={a.status} onChange={(e) => updateStatus(a._id, e.target.value)}>
                        {APPLICATION_STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
