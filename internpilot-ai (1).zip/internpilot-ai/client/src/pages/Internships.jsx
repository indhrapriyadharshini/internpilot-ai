import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { getErrorMessage } from '../api/client.js';

const EMPTY = { q: '', category: '', location: '', mode: '', skill: '', minStipend: '', sort: 'latest' };

export default function Internships() {
  const [draft, setDraft] = useState(EMPTY);
  const [filters, setFilters] = useState(EMPTY);
  const [page, setPage] = useState(1);
  const [result, setResult] = useState({ data: [], pages: 1, total: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const set = (key) => (e) => setDraft({ ...draft, [key]: e.target.value });

  useEffect(() => {
    setLoading(true);
    setError('');
    const params = Object.fromEntries(
      Object.entries({ ...filters, page, limit: 9 }).filter(([, v]) => v !== '' && v !== undefined)
    );
    api
      .get('/internships', { params })
      .then((r) => setResult(r.data))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, [filters, page]);

  const applyFilters = (e) => {
    e.preventDefault();
    setPage(1);
    setFilters(draft);
  };

  const reset = () => {
    setDraft(EMPTY);
    setFilters(EMPTY);
    setPage(1);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">Find internships</h1>
      <p className="mb-6 text-slate-500">{result.total} open opportunities</p>

      <form onSubmit={applyFilters} className="card mb-6 grid gap-3 md:grid-cols-4">
        <input className="input md:col-span-2" placeholder="Search title, skill or company" value={draft.q} onChange={set('q')} />
        <input className="input" placeholder="Category (e.g. Design)" value={draft.category} onChange={set('category')} />
        <input className="input" placeholder="Location" value={draft.location} onChange={set('location')} />
        <select className="input" value={draft.mode} onChange={set('mode')}>
          <option value="">Any work mode</option>
          <option value="remote">Remote</option>
          <option value="onsite">On-site</option>
          <option value="hybrid">Hybrid</option>
        </select>
        <input className="input" placeholder="Skill (e.g. react)" value={draft.skill} onChange={set('skill')} />
        <input className="input" type="number" min="0" placeholder="Minimum stipend" value={draft.minStipend} onChange={set('minStipend')} />
        <select className="input" value={draft.sort} onChange={set('sort')}>
          <option value="latest">Newest first</option>
          <option value="stipend">Highest stipend</option>
          <option value="deadline">Closing soonest</option>
        </select>
        <div className="flex gap-2 md:col-span-4">
          <button className="btn-primary">Apply filters</button>
          <button type="button" className="btn-outline" onClick={reset}>Reset</button>
        </div>
      </form>

      {error && <p className="mb-4 text-red-600">{error}</p>}
      {loading ? (
        <p className="text-slate-500">Loading internships...</p>
      ) : result.data.length === 0 ? (
        <p className="text-slate-500">No internships match your filters.</p>
      ) : (
        <div className="grid gap-5 md:grid-cols-3">
          {result.data.map((i) => (
            <Link key={i._id} to={`/internships/${i._id}`} className="card transition hover:shadow-md">
              <h3 className="text-lg font-semibold">{i.title}</h3>
              <p className="text-sm text-slate-600">{i.company}</p>
              <p className="mt-2 text-xs text-slate-500">{i.location || 'Flexible location'} · {i.mode}</p>
              <div className="mt-3 flex flex-wrap gap-1">
                {i.skills.slice(0, 5).map((s) => (
                  <span key={s} className="rounded bg-indigo-50 px-2 py-0.5 text-xs text-indigo-700">{s}</span>
                ))}
              </div>
              <p className="mt-3 text-sm font-medium">{i.stipend ? `₹${i.stipend.toLocaleString('en-IN')}/month` : 'Stipend not specified'}</p>
            </Link>
          ))}
        </div>
      )}

      <div className="mt-8 flex items-center justify-center gap-3">
        <button className="btn-outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
        <span className="text-sm">Page {page} of {Math.max(result.pages, 1)}</span>
        <button className="btn-outline" disabled={page >= result.pages} onClick={() => setPage((p) => p + 1)}>Next</button>
      </div>
    </div>
  );
}
