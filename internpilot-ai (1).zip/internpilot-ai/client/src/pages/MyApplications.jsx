import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';
import StatusBadge from '../components/StatusBadge.jsx';

export default function MyApplications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () =>
    api
      .get('/applications/mine')
      .then((r) => setApplications(r.data.data))
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const withdraw = async (id) => {
    if (!window.confirm('Withdraw this application?')) return;
    try {
      await api.patch(`/applications/${id}/withdraw`);
      load();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  if (loading) return <p className="text-slate-500">Loading applications...</p>;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">My applications</h1>
      {error && <p className="mb-4 text-red-600">{error}</p>}
      {applications.length === 0 ? (
        <p className="text-slate-500">No applications yet.</p>
      ) : (
        <div className="space-y-4">
          {applications.map((a) => (
            <div key={a._id} className="card">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{a.internship?.title || 'Internship removed'}</h2>
                  <p className="text-sm text-slate-600">{a.internship?.company} · Applied {new Date(a.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <StatusBadge status={a.status} />
                  {!['accepted', 'rejected', 'withdrawn'].includes(a.status) && (
                    <button className="btn-outline text-red-600" onClick={() => withdraw(a._id)}>Withdraw</button>
                  )}
                </div>
              </div>
              <details className="mt-3">
                <summary className="cursor-pointer text-sm text-indigo-600">Status timeline</summary>
                <ol className="mt-2 space-y-1 border-l-2 border-indigo-200 pl-4 text-sm">
                  {a.statusHistory.map((h, i) => (
                    <li key={i}>
                      <span className="font-medium capitalize">{h.status.replace(/_/g, ' ')}</span>
                      <span className="text-slate-500"> · {new Date(h.at).toLocaleString()}</span>
                      {h.note && <span className="block text-slate-600">{h.note}</span>}
                    </li>
                  ))}
                </ol>
              </details>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
