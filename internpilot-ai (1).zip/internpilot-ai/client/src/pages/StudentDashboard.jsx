import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import StatusBadge from '../components/StatusBadge.jsx';

const profileChecks = (p = {}) => [
  p.phone, p.college, p.degree, p.graduationYear, p.skills?.length, p.interests?.length, p.bio, p.resumeText,
];

export default function StudentDashboard() {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [recommendations, setRecommendations] = useState([]);

  useEffect(() => {
    api.get('/applications/mine').then((r) => setApplications(r.data.data)).catch(() => {});
    api.get('/ai/recommendations').then((r) => setRecommendations(r.data.data.slice(0, 3))).catch(() => {});
  }, []);

  const checks = profileChecks(user.profile);
  const completeness = Math.round((checks.filter(Boolean).length / checks.length) * 100);
  const count = (status) => applications.filter((a) => a.status === status).length;

  const stats = [
    ['Applications', applications.length],
    ['Under review', count('under_review') + count('applied')],
    ['Shortlisted / interview', count('shortlisted') + count('interview')],
    ['Accepted', count('accepted')],
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Hi, {user.name.split(' ')[0]} 👋</h1>
        <p className="text-slate-500">Here is where your internship journey stands today.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        {stats.map(([label, value]) => (
          <div key={label} className="card">
            <p className="text-sm text-slate-500">{label}</p>
            <p className="mt-1 text-3xl font-bold text-indigo-700">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="card">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Profile completeness</h2>
            <span className="text-sm font-medium text-indigo-700">{completeness}%</span>
          </div>
          <div className="h-2 w-full rounded bg-slate-200">
            <div className="h-2 rounded bg-indigo-600" style={{ width: `${completeness}%` }} />
          </div>
          <p className="mt-3 text-sm text-slate-600">
            A complete profile (skills, resume, bio) gives better AI recommendations.
          </p>
          <Link to="/profile" className="btn-outline mt-4">Update profile</Link>
        </div>

        <div className="card">
          <h2 className="mb-3 font-semibold">Top recommendations</h2>
          {recommendations.length === 0 ? (
            <p className="text-sm text-slate-500">Add your skills in your profile to see matches.</p>
          ) : (
            <ul className="space-y-3">
              {recommendations.map((r) => (
                <li key={r.internshipId}>
                  <Link to={`/internships/${r.internship._id}`} className="font-medium text-indigo-700 hover:underline">{r.title}</Link>
                  <span className="ml-2 text-xs text-slate-500">{r.company} · {r.score}% match</span>
                </li>
              ))}
            </ul>
          )}
          <Link to="/recommendations" className="mt-4 inline-block text-sm text-indigo-600">See all recommendations →</Link>
        </div>
      </div>

      <div className="card">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Recent applications</h2>
          <Link to="/applications" className="text-sm text-indigo-600">View all</Link>
        </div>
        {applications.length === 0 ? (
          <p className="text-sm text-slate-500">You have not applied anywhere yet. <Link to="/internships" className="text-indigo-600">Browse internships</Link></p>
        ) : (
          <ul className="divide-y">
            {applications.slice(0, 5).map((a) => (
              <li key={a._id} className="flex items-center justify-between py-3">
                <span>{a.internship?.title} <span className="text-sm text-slate-500">at {a.internship?.company}</span></span>
                <StatusBadge status={a.status} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
