import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';
import StatusBadge from '../components/StatusBadge.jsx';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [applications, setApplications] = useState([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [error, setError] = useState('');

  const loadUsers = () =>
    api
      .get('/admin/users', { params: { q: search || undefined, role: roleFilter || undefined } })
      .then((r) => setUsers(r.data.data))
      .catch((err) => setError(getErrorMessage(err)));

  useEffect(() => {
    api.get('/admin/stats').then((r) => setStats(r.data.data)).catch((err) => setError(getErrorMessage(err)));
    api.get('/admin/applications').then((r) => setApplications(r.data.data)).catch(() => {});
  }, []);

  useEffect(() => {
    loadUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleFilter]);

  const toggleStatus = async (u) => {
    setError('');
    try {
      await api.patch(`/admin/users/${u._id}/status`, { isActive: !u.isActive });
      loadUsers();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const cards = stats
    ? [
        ['Students', stats.users.student || 0],
        ['Providers', stats.users.provider || 0],
        ['Active internships', stats.activeInternships],
        ['Total applications', stats.totalApplications],
      ]
    : [];

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Admin dashboard</h1>
      {error && <p className="text-red-600">{error}</p>}

      <div className="grid gap-4 md:grid-cols-4">
        {cards.map(([label, value]) => (
          <div key={label} className="card">
            <p className="text-sm text-slate-500">{label}</p>
            <p className="mt-1 text-3xl font-bold text-indigo-700">{value}</p>
          </div>
        ))}
      </div>

      {stats && (
        <div className="card">
          <h2 className="mb-3 font-semibold">Applications by status</h2>
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.applicationsByStatus).length === 0 && <span className="text-sm text-slate-500">No applications yet.</span>}
            {Object.entries(stats.applicationsByStatus).map(([status, count]) => (
              <span key={status} className="flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-sm">
                <StatusBadge status={status} /> {count}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="card">
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <h2 className="mr-auto font-semibold">Users</h2>
          <input className="input w-60" placeholder="Search name or email" value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && loadUsers()} />
          <select className="input w-40" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
            <option value="">All roles</option>
            <option value="student">Students</option>
            <option value="provider">Providers</option>
            <option value="admin">Admins</option>
          </select>
          <button className="btn-outline" onClick={loadUsers}>Search</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b text-slate-500">
              <tr><th className="py-2">Name</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u._id} className="border-b last:border-0">
                  <td className="py-2 font-medium">{u.name}</td>
                  <td>{u.email}</td>
                  <td className="capitalize">{u.role}</td>
                  <td>{u.isActive ? <span className="text-green-700">Active</span> : <span className="text-red-600">Disabled</span>}</td>
                  <td>
                    {u.role !== 'admin' && (
                      <button className="btn-outline" onClick={() => toggleStatus(u)}>{u.isActive ? 'Disable' : 'Enable'}</button>
                    )}
                  </td>
                </tr>
              ))}
              {users.length === 0 && <tr><td colSpan={5} className="py-4 text-slate-500">No users found.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h2 className="mb-4 font-semibold">Recent applications</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b text-slate-500">
              <tr><th className="py-2">Student</th><th>Internship</th><th>Company</th><th>Status</th><th>Applied</th></tr>
            </thead>
            <tbody>
              {applications.map((a) => (
                <tr key={a._id} className="border-b last:border-0">
                  <td className="py-2">{a.student?.name}</td>
                  <td>{a.internship?.title}</td>
                  <td>{a.internship?.company}</td>
                  <td><StatusBadge status={a.status} /></td>
                  <td>{new Date(a.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
              {applications.length === 0 && <tr><td colSpan={5} className="py-4 text-slate-500">No applications yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
