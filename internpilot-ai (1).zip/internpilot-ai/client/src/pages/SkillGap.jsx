import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';

export default function SkillGap() {
  const [internships, setInternships] = useState([]);
  const [internshipId, setInternshipId] = useState('');
  const [result, setResult] = useState(null);
  const [mode, setMode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/internships', { params: { limit: 50 } }).then((r) => setInternships(r.data.data)).catch(() => {});
  }, []);

  const analyze = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const { data } = await api.post('/ai/skill-gap', { internshipId });
      setResult(data.data);
      setMode(data.mode);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Skill gap analyzer</h1>
        <p className="text-slate-500">Compare your profile skills with an internship and get a learning plan.</p>
      </div>

      <form onSubmit={analyze} className="card flex flex-wrap items-end gap-3">
        <div className="min-w-[260px] flex-1">
          <label className="label" htmlFor="internship">Target internship</label>
          <select id="internship" required className="input" value={internshipId} onChange={(e) => setInternshipId(e.target.value)}>
            <option value="">Select an internship...</option>
            {internships.map((i) => <option key={i._id} value={i._id}>{i.title} – {i.company}</option>)}
          </select>
        </div>
        <button disabled={busy || !internshipId} className="btn-primary">{busy ? 'Analyzing...' : 'Analyze gap'}</button>
      </form>
      {error && <p className="text-red-600">{error}</p>}

      {result && (
        <div className="space-y-6">
          <div className="card">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-sm text-slate-500">Readiness</p>
                <p className="text-4xl font-bold text-indigo-700">{result.readiness}%</p>
              </div>
              <span className="rounded-full bg-slate-200 px-3 py-1 text-xs">{mode === 'ai' ? 'AI learning plan' : 'Rule-based plan'}</span>
            </div>
            <div className="mt-4 grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-2 font-semibold">You have</h3>
                <div className="flex flex-wrap gap-2">
                  {result.matched.length ? result.matched.map((s) => <span key={s} className="rounded bg-green-100 px-2 py-1 text-sm text-green-700">{s}</span>) : <span className="text-sm text-slate-500">None of the required skills yet</span>}
                </div>
              </div>
              <div>
                <h3 className="mb-2 font-semibold">Missing</h3>
                <div className="flex flex-wrap gap-2">
                  {result.missing.length ? result.missing.map((s) => <span key={s} className="rounded bg-red-100 px-2 py-1 text-sm text-red-700">{s}</span>) : <span className="text-sm text-green-700">You meet every required skill!</span>}
                </div>
              </div>
            </div>
          </div>

          {result.learningPlan.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Learning plan</h2>
              {result.learningPlan.map((step) => (
                <div key={step.skill} className="card">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold capitalize">{step.skill}</h3>
                    <span className="text-sm text-slate-500">≈ {step.estimatedWeeks} week(s)</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-700">{step.why}</p>
                  <ul className="mt-2 list-disc pl-5 text-sm text-indigo-700">
                    {step.resources.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
