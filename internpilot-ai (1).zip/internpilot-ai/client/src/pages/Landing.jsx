import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const FEATURES = [
  ['AI Recommendations', 'Get internships ranked by how well they match your skills and interests.'],
  ['Resume Analyzer', 'Score your resume, spot weak sections and get concrete improvements.'],
  ['Skill Gap Analysis', 'See exactly which skills you are missing for a role and how to learn them.'],
  ['Interview Preparation', 'Practice role-specific questions with tips tailored to each internship.'],
  ['Bilingual Chatbot', 'Ask questions in English or Tamil and get guidance any time.'],
  ['Application Tracking', 'Follow every application from submitted to accepted, with email updates.'],
];

const STEPS = [
  ['Create your profile', 'Add your skills, interests and resume.'],
  ['Discover & apply', 'Search filtered listings and apply in one click.'],
  ['Track & prepare', 'Monitor status and prepare with AI before interviews.'],
];

export default function Landing() {
  const { user } = useAuth();
  return (
    <div className="space-y-20">
      <section className="rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-700 px-6 py-20 text-center text-white">
        <h1 className="text-4xl font-bold md:text-5xl">Land your dream internship with AI</h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-indigo-100">
          InternPilot AI matches you with the right internships, reviews your resume, closes skill gaps and prepares you for interviews.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to={user ? '/dashboard' : '/register'} className="rounded-lg bg-white px-6 py-3 font-semibold text-indigo-700">
            {user ? 'Go to dashboard' : 'Get started free'}
          </Link>
          <Link to="/internships" className="rounded-lg border border-white px-6 py-3 font-semibold text-white">
            Browse internships
          </Link>
        </div>
      </section>

      <section>
        <h2 className="mb-8 text-center text-3xl font-bold">Everything you need in one platform</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {FEATURES.map(([title, text]) => (
            <div key={title} className="card">
              <h3 className="text-lg font-semibold text-indigo-700">{title}</h3>
              <p className="mt-2 text-slate-600">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-8 text-center text-3xl font-bold">How it works</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {STEPS.map(([title, text], i) => (
            <div key={title} className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-indigo-600 font-bold text-white">{i + 1}</div>
              <h3 className="mt-4 font-semibold">{title}</h3>
              <p className="mt-1 text-slate-600">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card text-center">
        <h2 className="text-2xl font-bold">Are you an internship provider?</h2>
        <p className="mt-2 text-slate-600">Post internships, review applicants and update candidate status in one place.</p>
        <Link to="/register" className="btn-primary mt-5">Register as a provider</Link>
      </section>
    </div>
  );
}
