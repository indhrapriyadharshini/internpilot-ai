import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const List = ({ title, items = [] }) =>
  items.length > 0 && (
    <div>
      <h3 className="mb-2 font-semibold">{title}</h3>
      <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">
        {items.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );

export default function ResumeAnalyzer() {
  const { user } = useAuth();
  const [resumeText, setResumeText] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [result, setResult] = useState(null);
  const [mode, setMode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user?.profile?.resumeText) setResumeText(user.profile.resumeText);
  }, [user]);

  const analyze = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const { data } = await api.post('/ai/resume/analyze', { resumeText, targetRole });
      setResult(data.data);
      setMode(data.mode);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">AI resume analyzer</h1>
        <p className="text-slate-500">Paste your resume text below. It is saved to your profile for interview prep.</p>
      </div>

      <form onSubmit={analyze} className="card space-y-4">
        <div>
          <label className="label" htmlFor="target">Target role (optional)</label>
          <input id="target" className="input" placeholder="e.g. Frontend Developer Intern" value={targetRole} onChange={(e) => setTargetRole(e.target.value)} />
        </div>
        <div>
          <label className="label" htmlFor="resume">Resume text</label>
          <textarea id="resume" rows={12} required minLength={50} maxLength={20000} className="input font-mono text-xs" value={resumeText} onChange={(e) => setResumeText(e.target.value)} placeholder="Paste your resume text here (copy from your PDF or Word file)." />
          <p className="mt-1 text-xs text-slate-500">{resumeText.length}/20000 characters</p>
        </div>
        {error && <p className="text-red-600">{error}</p>}
        <button disabled={busy} className="btn-primary">{busy ? 'Analyzing...' : 'Analyze resume'}</button>
      </form>

      {result && (
        <div className="card space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm text-slate-500">Resume score</p>
              <p className="text-4xl font-bold text-indigo-700">{result.score}<span className="text-lg text-slate-400">/100</span></p>
            </div>
            <span className="rounded-full bg-slate-200 px-3 py-1 text-xs">{mode === 'ai' ? 'AI analysis' : 'Rule-based (AI not configured)'}</span>
          </div>
          {result.summary && <p className="text-slate-700">{result.summary}</p>}
          <div className="grid gap-6 md:grid-cols-2">
            <List title="Strengths" items={result.strengths} />
            <List title="Weaknesses" items={result.weaknesses} />
            <List title="Suggestions" items={result.suggestions} />
            <List title="Detected skills" items={result.detectedSkills} />
            <List title="Missing sections" items={result.missingSections} />
          </div>
        </div>
      )}
    </div>
  );
}
