import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { getErrorMessage } from '../api/client.js';

export default function Recommendations() {
  const [items, setItems] = useState([]);
  const [mode, setMode] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api
      .get('/ai/recommendations')
      .then((r) => { setItems(r.data.data); setMode(r.data.mode); })
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">AI internship recommendations</h1>
          <p className="text-slate-500">Ranked by skill match, interests and location preferences.</p>
        </div>
        {mode && <span className="rounded-full bg-slate-200 px-3 py-1 text-xs">{mode === 'ai' ? 'Powered by OpenAI' : 'Rule-based (AI not configured)'}</span>}
      </div>

      {error && <p className="text-red-600">{error}</p>}
      {loading && <p className="text-slate-500">Analysing your profile...</p>}
      {!loading && items.length === 0 && (
        <p className="text-slate-500">No matches yet. Add skills and interests in your <Link to="/profile" className="text-indigo-600">profile</Link>.</p>
      )}

      <div className="space-y-4">
        {items.map((r) => (
          <div key={r.internshipId} className="card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <Link to={`/internships/${r.internship._id}`} className="text-lg font-semibold text-indigo-700 hover:underline">{r.title}</Link>
                <p className="text-sm text-slate-600">{r.company} · {r.mode} · {r.location || 'Flexible'}</p>
              </div>
              <div className="w-40">
                <p className="text-right text-sm font-semibold text-indigo-700">{r.score}% match</p>
                <div className="mt-1 h-2 rounded bg-slate-200"><div className="h-2 rounded bg-indigo-600" style={{ width: `${r.score}%` }} /></div>
              </div>
            </div>
            <p className="mt-3 text-slate-700">{r.reason}</p>
            {r.matchedSkills?.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {r.matchedSkills.map((s) => <span key={s} className="rounded bg-green-50 px-2 py-0.5 text-xs text-green-700">✓ {s}</span>)}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
