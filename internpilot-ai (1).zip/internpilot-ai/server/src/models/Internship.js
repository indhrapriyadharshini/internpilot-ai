import mongoose from 'mongoose';

const internshipSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 150 },
    description: { type: String, required: true, maxlength: 5000 },
    company: { type: String, required: true, trim: true, maxlength: 120 },
    provider: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    category: { type: String, default: 'General', trim: true },
    skills: { type: [String], default: [] },
    requirements: { type: [String], default: [] },
    location: { type: String, default: '', trim: true },
    mode: { type: String, enum: ['remote', 'onsite', 'hybrid'], default: 'onsite' },
    duration: { type: String, default: '', trim: true },
    stipend: { type: Number, default: 0, min: 0 },
    openings: { type: Number, default: 1, min: 1 },
    deadline: { type: Date },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

internshipSchema.index({ title: 'text', description: 'text', skills: 'text', company: 'text' });

export default mongoose.model('Internship', internshipSchema);
