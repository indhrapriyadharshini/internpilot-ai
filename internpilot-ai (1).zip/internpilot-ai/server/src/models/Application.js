import mongoose from 'mongoose';

export const APPLICATION_STATUSES = [
  'applied',
  'under_review',
  'shortlisted',
  'interview',
  'rejected',
  'accepted',
  'withdrawn',
];

const applicationSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    internship: { type: mongoose.Schema.Types.ObjectId, ref: 'Internship', required: true, index: true },
    status: { type: String, enum: APPLICATION_STATUSES, default: 'applied' },
    coverLetter: { type: String, default: '', maxlength: 2000 },
    statusHistory: [
      {
        status: { type: String, enum: APPLICATION_STATUSES },
        note: { type: String, default: '', maxlength: 500 },
        at: { type: Date, default: Date.now },
        _id: false,
      },
    ],
  },
  { timestamps: true }
);

// A student can apply to the same internship only once.
applicationSchema.index({ student: 1, internship: 1 }, { unique: true });

export default mongoose.model('Application', applicationSchema);
