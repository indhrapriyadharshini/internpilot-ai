import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const profileSchema = new mongoose.Schema(
  {
    phone: { type: String, trim: true, default: '' },
    college: { type: String, trim: true, default: '' },
    degree: { type: String, trim: true, default: '' },
    graduationYear: { type: Number, min: 2000, max: 2100 },
    skills: { type: [String], default: [] },
    interests: { type: [String], default: [] },
    preferredLocations: { type: [String], default: [] },
    bio: { type: String, trim: true, maxlength: 1000, default: '' },
    linkedin: { type: String, trim: true, default: '' },
    portfolio: { type: String, trim: true, default: '' },
    resumeText: { type: String, default: '', maxlength: 20000 },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6, select: false },
    role: { type: String, enum: ['student', 'provider', 'admin'], default: 'student' },
    company: { type: String, trim: true, default: '' },
    isActive: { type: Boolean, default: true },
    profile: { type: profileSchema, default: () => ({}) },
  },
  { timestamps: true }
);

// Hash the password before saving (validation has already run on the plain text).
userSchema.pre('save', async function () {
  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

export default mongoose.model('User', userSchema);
