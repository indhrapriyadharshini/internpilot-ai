import { Router } from 'express';
import { body } from 'express-validator';
import {
  listInternships,
  getInternship,
  listMyInternships,
  createInternship,
  updateInternship,
  deleteInternship,
} from '../controllers/internshipController.js';
import { protect, authorize } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();

const internshipRules = [
  body('title').optional().trim().isLength({ min: 3, max: 150 }).withMessage('Title must be 3-150 characters'),
  body('description').optional().trim().isLength({ min: 30, max: 5000 }).withMessage('Description must be 30-5000 characters'),
  body('mode').optional().isIn(['remote', 'onsite', 'hybrid']).withMessage('Mode must be remote, onsite or hybrid'),
  body('stipend').optional().isFloat({ min: 0 }).withMessage('Stipend must be a positive number'),
  body('openings').optional().isInt({ min: 1 }).withMessage('Openings must be at least 1'),
  body('deadline').optional({ values: 'falsy' }).isISO8601().withMessage('Deadline must be a valid date'),
  body('skills').optional().isArray({ max: 50 }).withMessage('Skills must be an array'),
  body('isActive').optional().isBoolean().withMessage('isActive must be true or false'),
];

router.get('/', listInternships);
router.get('/mine', protect, authorize('provider', 'admin'), listMyInternships);
router.get('/:id', getInternship);
router.post('/', protect, authorize('provider', 'admin'), internshipRules, validate, createInternship);
router.put('/:id', protect, authorize('provider', 'admin'), internshipRules, validate, updateInternship);
router.delete('/:id', protect, authorize('provider', 'admin'), deleteInternship);

export default router;
