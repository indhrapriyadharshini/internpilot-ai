import { Router } from 'express';
import { body } from 'express-validator';
import { APPLICATION_STATUSES } from '../models/Application.js';
import {
  applyToInternship,
  getMyApplications,
  getInternshipApplications,
  updateApplicationStatus,
  withdrawApplication,
} from '../controllers/applicationController.js';
import { protect, authorize } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.use(protect);

router.post(
  '/',
  authorize('student'),
  [
    body('internshipId').isMongoId().withMessage('A valid internshipId is required'),
    body('coverLetter').optional().isLength({ max: 2000 }).withMessage('Cover letter must be under 2000 characters'),
  ],
  validate,
  applyToInternship
);

router.get('/mine', authorize('student'), getMyApplications);
router.get('/internship/:internshipId', authorize('provider', 'admin'), getInternshipApplications);

router.patch(
  '/:id/status',
  authorize('provider', 'admin'),
  [
    body('status').isIn(APPLICATION_STATUSES).withMessage('Invalid application status'),
    body('note').optional().isLength({ max: 500 }).withMessage('Note must be under 500 characters'),
  ],
  validate,
  updateApplicationStatus
);

router.patch('/:id/withdraw', authorize('student'), withdrawApplication);

export default router;
