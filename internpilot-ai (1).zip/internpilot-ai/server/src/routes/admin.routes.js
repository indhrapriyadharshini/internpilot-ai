import { Router } from 'express';
import { body } from 'express-validator';
import { getStats, listUsers, setUserStatus, listAllApplications } from '../controllers/adminController.js';
import { protect, authorize } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.use(protect, authorize('admin'));

router.get('/stats', getStats);
router.get('/users', listUsers);
router.patch(
  '/users/:id/status',
  [body('isActive').isBoolean().withMessage('isActive must be true or false')],
  validate,
  setUserStatus
);
router.get('/applications', listAllApplications);

export default router;
