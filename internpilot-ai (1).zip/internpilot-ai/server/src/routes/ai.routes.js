import { Router } from 'express';
import { body } from 'express-validator';
import {
  getStatus,
  getRecommendations,
  analyzeResumeText,
  skillGap,
  interviewPrep,
  chat,
} from '../controllers/aiController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.use(protect);

router.get('/status', getStatus);
router.get('/recommendations', getRecommendations);
router.post(
  '/resume/analyze',
  [
    body('resumeText').isLength({ min: 50, max: 20000 }).withMessage('Resume text must be 50-20000 characters'),
    body('targetRole').optional().isLength({ max: 100 }).withMessage('Target role is too long'),
  ],
  validate,
  analyzeResumeText
);
router.post('/skill-gap', [body('internshipId').isMongoId().withMessage('A valid internshipId is required')], validate, skillGap);
router.post('/interview-prep', [body('internshipId').isMongoId().withMessage('A valid internshipId is required')], validate, interviewPrep);
router.post(
  '/chat',
  [
    body('messages').isArray({ min: 1, max: 20 }).withMessage('Provide 1-20 chat messages'),
    body('language').optional().isIn(['en', 'ta']).withMessage('Language must be en or ta'),
  ],
  validate,
  chat
);

export default router;
