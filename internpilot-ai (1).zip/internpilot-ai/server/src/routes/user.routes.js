import { Router } from 'express';
import { body } from 'express-validator';
import { getProfile, updateProfile } from '../controllers/userController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.use(protect);

router.get('/profile', getProfile);
router.put(
  '/profile',
  [
    body('name').optional().trim().isLength({ min: 2, max: 100 }).withMessage('Name must be 2-100 characters'),
    body('profile.skills').optional().isArray({ max: 50 }).withMessage('Skills must be an array (max 50)'),
    body('profile.interests').optional().isArray({ max: 20 }).withMessage('Interests must be an array (max 20)'),
    body('profile.bio').optional().isLength({ max: 1000 }).withMessage('Bio must be under 1000 characters'),
    body('profile.linkedin').optional({ values: 'falsy' }).isURL().withMessage('LinkedIn must be a valid URL'),
    body('profile.portfolio').optional({ values: 'falsy' }).isURL().withMessage('Portfolio must be a valid URL'),
  ],
  validate,
  updateProfile
);

export default router;
