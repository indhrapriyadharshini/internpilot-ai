import Notification from '../models/Notification.js';
import { sendEmail } from './email.service.js';
import { escapeHtml } from '../utils/helpers.js';

// Saves an in-app notification and sends the matching email (fire-and-forget).
export async function notifyUser({ userId, email, title, message }) {
  try {
    await Notification.create({ user: userId, title, message });
  } catch (err) {
    console.error('Notification save failed:', err.message);
  }
  if (email) {
    sendEmail({
      to: email,
      subject: `[InternPilot AI] ${title}`,
      text: message,
      html: `<h3>${escapeHtml(title)}</h3><p>${escapeHtml(message)}</p><p>- InternPilot AI</p>`,
    });
  }
}
