import nodemailer from 'nodemailer';
import { env } from '../config/env.js';

let transporter = null;

const getTransporter = () => {
  if (!env.smtp.user || !env.smtp.pass) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.port === 465,
      auth: { user: env.smtp.user, pass: env.smtp.pass },
    });
  }
  return transporter;
};

// Never throws: a failed email must not break the user's request.
export async function sendEmail({ to, subject, text, html }) {
  const t = getTransporter();
  if (!t) {
    console.log(`[email skipped: SMTP not configured] to=${to} subject="${subject}"`);
    return { skipped: true };
  }
  try {
    return await t.sendMail({ from: env.emailFrom, to, subject, text, html });
  } catch (err) {
    console.error('Email failed:', err.message);
    return { failed: true };
  }
}
