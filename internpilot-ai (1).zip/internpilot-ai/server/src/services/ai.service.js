import OpenAI from 'openai';
import { env } from '../config/env.js';
import { AppError } from '../utils/AppError.js';
import { escapeRegex, normalizeSkills } from '../utils/helpers.js';

// The OpenAI client exists only when OPENAI_API_KEY is set on the server.
const client = env.openaiKey ? new OpenAI({ apiKey: env.openaiKey }) : null;

const SKILL_DICTIONARY = [
  'javascript', 'typescript', 'react', 'node.js', 'express', 'mongodb', 'sql', 'python',
  'java', 'c++', 'c#', 'html', 'css', 'tailwind', 'git', 'docker', 'aws', 'linux',
  'machine learning', 'data analysis', 'excel', 'power bi', 'tableau', 'figma', 'communication',
  'problem solving', 'teamwork', 'rest api', 'graphql', 'flutter', 'android', 'kotlin', 'php',
  'laravel', 'django', 'flask', 'pandas', 'numpy', 'tensorflow', 'pytorch', 'seo',
  'digital marketing', 'content writing', 'ui/ux', 'jest', 'selenium', 'networking',
  'cybersecurity', 'spring boot', '.net', 'rust',
];

// Runs the AI task when available; otherwise (or on AI error) runs the rule-based fallback.
const withFallback = async (aiTask, fallback) => {
  if (!client) return { mode: 'rule-based', data: fallback() };
  try {
    return { mode: 'ai', data: await aiTask() };
  } catch (err) {
    console.error('[AI] falling back to rule-based:', err.message);
    return { mode: 'rule-based', data: fallback() };
  }
};

const callJSON = async (system, user) => {
  const res = await client.chat.completions.create({
    model: env.openaiModel,
    temperature: 0.4,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: `${system}\nRespond ONLY with a valid JSON object.` },
      { role: 'user', content: user },
    ],
  });
  return JSON.parse(res.choices[0].message.content);
};

export const aiStatus = () => ({ enabled: Boolean(client), model: client ? env.openaiModel : null });

export const extractSkills = (text = '') => {
  const haystack = ` ${String(text).toLowerCase()} `;
  return SKILL_DICTIONARY.filter((skill) =>
    new RegExp(`[^a-z0-9+#.]${escapeRegex(skill)}[^a-z0-9+#]`).test(haystack)
  );
};

// Scores how well an internship fits a student profile (0-100).
export const scoreInternship = (profile = {}, internship) => {
  const userSkills = normalizeSkills(profile.skills);
  const interests = normalizeSkills(profile.interests);
  const required = normalizeSkills(internship.skills);
  const matchedSkills = required.filter((s) => userSkills.includes(s));
  const skillRatio = required.length ? matchedSkills.length / required.length : 0;

  const text = `${internship.category} ${internship.title} ${internship.description}`.toLowerCase();
  const interestHit = interests.some((i) => text.includes(i)) ? 1 : 0;

  const prefs = (profile.preferredLocations || []).map((l) => l.toLowerCase());
  const locationHit =
    internship.mode === 'remote' || prefs.some((l) => String(internship.location).toLowerCase().includes(l)) ? 1 : 0;

  const score = Math.round((skillRatio * 0.7 + interestHit * 0.2 + locationHit * 0.1) * 100);
  return { score, matchedSkills };
};

export const recommendInternships = async (profile, internships) => {
  const base = internships
    .map((internship) => ({
      internshipId: internship._id,
      internship,
      ...scoreInternship(profile, internship),
    }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 10)
    .map((r) => ({
      ...r,
      reason: r.matchedSkills.length
        ? `You match ${r.matchedSkills.length} required skill(s): ${r.matchedSkills.join(', ')}`
        : 'Matches your interests or location preferences',
    }));

  return withFallback(
    async () => {
      const candidates = base.slice(0, 8).map((r) => ({
        id: String(r.internshipId),
        title: r.internship.title,
        company: r.internship.company,
        skills: r.internship.skills,
      }));
      const out = await callJSON(
        'You are a career advisor for students. For each candidate internship, explain in at most 25 words why it suits this student.',
        `Student skills: ${(profile.skills || []).join(', ') || 'none'}\nInterests: ${(profile.interests || []).join(', ') || 'none'}\nCandidates: ${JSON.stringify(candidates)}\nReturn JSON: {"reasons": {"<id>": "<reason>"}}`
      );
      return base.map((r) => ({ ...r, reason: out.reasons?.[String(r.internshipId)] || r.reason }));
    },
    () => base
  );
};

const ruleBasedResume = (text, targetRole) => {
  const lower = text.toLowerCase();
  const detectedSkills = extractSkills(text);
  const words = text.trim().split(/\s+/).length;
  const hasNumbers = /\d+%|\d+\+|\b\d{2,}\b/.test(text);
  const hasEmail = /@/.test(text);
  const sectionKeywords = ['experience', 'education', 'projects', 'skills', 'achievements', 'certification', 'summary'];
  const foundSections = sectionKeywords.filter((s) => lower.includes(s));
  const missingSections = ['experience', 'education', 'projects', 'skills'].filter((s) => !lower.includes(s));

  const score = Math.min(
    100,
    detectedSkills.length * 4 + foundSections.length * 6 + (words > 250 ? 15 : words > 120 ? 8 : 0) + (hasNumbers ? 10 : 0) + (hasEmail ? 5 : 0)
  );

  const weaknesses = [];
  const suggestions = [];
  if (words < 250) weaknesses.push('The resume is quite short for an internship application.');
  if (!hasNumbers) suggestions.push('Quantify achievements with numbers, for example "reduced load time by 30%".');
  if (!hasEmail) suggestions.push('Add a professional contact email at the top.');
  if (missingSections.length) suggestions.push(`Consider adding these sections: ${missingSections.join(', ')}.`);
  if (detectedSkills.length < 5) suggestions.push('List more relevant technical skills and tools.');

  return {
    score,
    summary: `Rule-based analysis (AI not configured). Target role: ${targetRole || 'General internship'}.`,
    detectedSkills,
    strengths: detectedSkills.length ? [`Mentions ${detectedSkills.length} recognised skills`] : [],
    weaknesses,
    suggestions,
    missingSections,
  };
};

export const analyzeResume = (resumeText, targetRole = '') =>
  withFallback(
    () =>
      callJSON(
        'You are an expert resume reviewer for students applying to internships. Be honest and constructive.',
        `Target role: ${targetRole || 'General internship'}\nResume:\n"""${resumeText.slice(0, 6000)}"""\nReturn JSON: {"score": number 0-100, "summary": string, "detectedSkills": string[], "strengths": string[], "weaknesses": string[], "suggestions": string[], "missingSections": string[]}`
      ),
    () => ruleBasedResume(resumeText, targetRole)
  );

export const analyzeSkillGap = async (profileSkills = [], internship) => {
  const userSkills = normalizeSkills(profileSkills);
  const required = normalizeSkills(internship.skills);
  const matched = required.filter((s) => userSkills.includes(s));
  const missing = required.filter((s) => !userSkills.includes(s));
  const readiness = required.length ? Math.round((matched.length / required.length) * 100) : 0;

  if (missing.length === 0) {
    return { mode: 'rule-based', data: { required, matched, missing, readiness, learningPlan: [] } };
  }

  const fallbackPlan = () =>
    missing.map((skill) => ({
      skill,
      why: `Listed as a requirement for ${internship.title}`,
      resources: [`Official ${skill} documentation`, `Beginner ${skill} course (freeCodeCamp or YouTube)`],
      estimatedWeeks: 2,
    }));

  const { mode, data } = await withFallback(async () => {
    const out = await callJSON(
      'You are a career coach for students. Create a practical, realistic learning plan.',
      `Internship: ${internship.title} at ${internship.company}\nMissing skills: ${missing.join(', ')}\nStudent already knows: ${userSkills.join(', ') || 'none'}\nReturn JSON: {"learningPlan":[{"skill":string,"why":string,"resources":string[],"estimatedWeeks":number}]}`
    );
    return Array.isArray(out.learningPlan) && out.learningPlan.length ? out.learningPlan : fallbackPlan();
  }, fallbackPlan);

  return { mode, data: { required, matched, missing, readiness, learningPlan: data } };
};

export const buildInterviewPrep = (profile = {}, internship) => {
  const studentSkills = normalizeSkills(profile.skills);
  const required = normalizeSkills(internship.skills);

  const fallback = () => [
    { question: `Tell me about yourself and why you want to intern as a ${internship.title}.`, type: 'behavioral', tip: 'Keep it under 90 seconds: background, one project, and why this role.' },
    { question: 'Describe a project you are proud of.', type: 'behavioral', tip: 'Use STAR: Situation, Task, Action, Result.' },
    ...(required.length ? required.slice(0, 3) : studentSkills.slice(0, 3)).map((s) => ({
      question: `How have you used ${s} in a project, and what challenge did you face?`,
      type: 'technical',
      tip: `Be specific about your role and the outcome with ${s}.`,
    })),
    { question: 'Tell me about a time you worked in a team and faced a disagreement.', type: 'behavioral', tip: 'Focus on communication and what you learned.' },
    { question: `Why ${internship.company}, and what do you know about the company?`, type: 'role', tip: 'Read the company website and recent news before the interview.' },
    { question: 'Where do you see yourself in one year?', type: 'behavioral', tip: 'Show willingness to learn and grow with the team.' },
  ];

  return withFallback(
    async () => {
      const out = await callJSON(
        'You are a senior interviewer preparing a student for an internship interview. Generate realistic questions with short, practical tips.',
        `Role: ${internship.title} at ${internship.company}\nRequired skills: ${required.join(', ') || 'not specified'}\nStudent skills: ${studentSkills.join(', ') || 'not provided'}\nGenerate 8 questions mixing technical, behavioral and role-specific ones.\nReturn JSON: {"questions":[{"question":string,"type":"technical|behavioral|role","tip":string}]}`
      );
      return Array.isArray(out.questions) && out.questions.length ? out.questions : fallback();
    },
    fallback
  );
};

export const chatReply = async (messages, language = 'en') => {
  const isTamil = language === 'ta';
  const fallbackText = isTamil
    ? 'AI உதவியாளர் இன்னும் அமைக்கப்படவில்லை. server/.env கோப்பில் OPENAI_API_KEY சேர்த்து சேவையகத்தை மறுதொடக்கம் செய்யவும்.'
    : 'The AI chatbot is not configured yet. Add OPENAI_API_KEY to server/.env and restart the server.';

  if (!client) return { mode: 'rule-based', reply: fallbackText };

  const system = `You are InternPilot AI, a friendly assistant for students looking for internships. Help with finding internships, applications, resumes, interview preparation and skill development. Always reply in ${isTamil ? 'Tamil (Tamil script)' : 'English'}. Keep answers concise and practical.`;
  const history = messages
    .filter((m) => ['user', 'assistant'].includes(m.role))
    .slice(-12)
    .map((m) => ({ role: m.role, content: String(m.content).slice(0, 2000) }));

  try {
    const res = await client.chat.completions.create({
      model: env.openaiModel,
      temperature: 0.5,
      messages: [{ role: 'system', content: system }, ...history],
    });
    return { mode: 'ai', reply: res.choices[0].message.content };
  } catch (err) {
    console.error('[AI chat] error:', err.message);
    throw new AppError('AI chat is temporarily unavailable. Please try again.', 502);
  }
};
