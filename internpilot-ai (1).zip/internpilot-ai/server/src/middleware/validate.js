import { validationResult } from 'express-validator';
import { AppError } from '../utils/AppError.js';

// Converts express-validator errors into a 400 response.
export const validate = (req, _res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();
  return next(
    new AppError(
      'Validation failed',
      400,
      errors.array().map((e) => ({ field: e.path, message: e.msg }))
    )
  );
};
