import { AppError } from './AppError.js';

export const escapeRegex = (value = '') =>
  String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export const normalizeSkills = (input = []) => {
  const list = Array.isArray(input) ? input : String(input).split(',');
  return [...new Set(list.map((s) => String(s).trim().toLowerCase()).filter(Boolean))].slice(0, 50);
};

export const isPast = (date) => Boolean(date) && new Date(date) < new Date();

export const escapeHtml = (value = '') =>
  String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

// Throws 403 unless the user is an admin or owns the internship.
export const ensureOwner = (internship, user) => {
  if (user.role !== 'admin' && String(internship.provider) !== String(user._id)) {
    throw new AppError('You can only manage your own internships', 403);
  }
};
