import mongoose from 'mongoose';
import { env } from './config/env.js';
import { connectDB } from './config/db.js';
import User from './models/User.js';
import Internship from './models/Internship.js';

// Creates sample accounts and internships. Runs only on an empty database.
const run = async () => {
  await connectDB(env.mongoUri);

  if ((await User.countDocuments()) > 0) {
    console.log('Database already contains users. Seeding skipped.');
  } else {
    const password = process.env.SEED_PASSWORD || 'ChangeMe@123';
    if (!process.env.SEED_PASSWORD) console.warn('SEED_PASSWORD not set; using the default. Change it after login!');

    const admin = await User.create({ name: 'Platform Admin', email: 'admin@internpilot.local', password, role: 'admin' });
    const provider = await User.create({ name: 'Priya Provider', email: 'provider@internpilot.local', password, role: 'provider', company: 'TechNova Labs' });
    await User.create({
      name: 'Arun Student',
      email: 'student@internpilot.local',
      password,
      role: 'student',
      profile: {
        college: 'Sample Engineering College',
        degree: 'B.E. Computer Science',
        graduationYear: 2027,
        skills: ['javascript', 'react', 'node.js', 'mongodb', 'git'],
        interests: ['web development', 'backend'],
        preferredLocations: ['chennai', 'remote'],
      },
    });

    const inDays = (d) => new Date(Date.now() + d * 24 * 60 * 60 * 1000);
    await Internship.create([
      { title: 'Frontend Developer Intern', description: 'Build responsive React interfaces with Tailwind CSS and collaborate with designers on real product features.', company: 'TechNova Labs', provider: provider._id, category: 'Web Development', skills: ['javascript', 'react', 'tailwind', 'git'], location: 'Chennai', mode: 'hybrid', duration: '3 months', stipend: 15000, openings: 2, deadline: inDays(30) },
      { title: 'Full Stack Intern (MERN)', description: 'Work on REST APIs with Express and MongoDB, and React frontends, across a live SaaS product.', company: 'TechNova Labs', provider: provider._id, category: 'Web Development', skills: ['javascript', 'node.js', 'express', 'mongodb', 'react'], location: 'Remote', mode: 'remote', duration: '6 months', stipend: 20000, openings: 3, deadline: inDays(45) },
      { title: 'Backend Developer Intern', description: 'Design and test Node.js services, write database queries and improve API performance.', company: 'TechNova Labs', provider: provider._id, category: 'Backend', skills: ['node.js', 'express', 'sql', 'rest api', 'docker'], location: 'Bengaluru', mode: 'onsite', duration: '3 months', stipend: 18000, openings: 1, deadline: inDays(20) },
      { title: 'Data Analyst Intern', description: 'Clean datasets, build dashboards in Power BI and find insights for the growth team.', company: 'TechNova Labs', provider: provider._id, category: 'Data', skills: ['excel', 'sql', 'power bi', 'python', 'pandas'], location: 'Remote', mode: 'remote', duration: '3 months', stipend: 12000, openings: 2, deadline: inDays(25) },
      { title: 'UI/UX Design Intern', description: 'Create wireframes and prototypes in Figma and run usability tests with real users.', company: 'TechNova Labs', provider: provider._id, category: 'Design', skills: ['figma', 'ui/ux', 'communication'], location: 'Chennai', mode: 'onsite', duration: '2 months', stipend: 10000, openings: 1, deadline: inDays(35) },
      { title: 'Digital Marketing Intern', description: 'Support SEO, content writing and social campaigns for our product launches.', company: 'TechNova Labs', provider: provider._id, category: 'Marketing', skills: ['seo', 'content writing', 'digital marketing'], location: 'Remote', mode: 'remote', duration: '3 months', stipend: 8000, openings: 2, deadline: inDays(40) },
    ]);

    console.log('Seeded sample data. Accounts (password from SEED_PASSWORD):');
    console.log(`  Admin:    ${admin.email}`);
    console.log('  Provider: provider@internpilot.local');
    console.log('  Student:  student@internpilot.local');
  }

  await mongoose.disconnect();
};

run().catch((err) => {
  console.error('Seed failed:', err.message);
  process.exit(1);
});
