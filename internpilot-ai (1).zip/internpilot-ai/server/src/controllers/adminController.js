import User from '../models/User.js';
import Internship from '../models/Internship.js';
import Application from '../models/Application.js';
import { AppError, asyncHandler } from '../utils/AppError.js';
import { escapeRegex } from '../utils/helpers.js';

export const getStats = asyncHandler(async (_req, res) => {
  const [usersByRole, activeInternships, totalApplications, appsByStatus] = await Promise.all([
    User.aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]),
    Internship.countDocuments({ isActive: true }),
    Application.countDocuments(),
    Application.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
  ]);
  res.json({
    success: true,
    data: {
      users: Object.fromEntries(usersByRole.map((r) => [r._id, r.count])),
      activeInternships,
      totalApplications,
      applicationsByStatus: Object.fromEntries(appsByStatus.map((r) => [r._id, r.count])),
    },
  });
});

export const listUsers = asyncHandler(async (req, res) => {
  const { q, role } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = 20;
  const filter = {};
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }
  if (['student', 'provider', 'admin'].includes(role)) filter.role = role;

  const [data, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    User.countDocuments(filter),
  ]);
  res.json({ success: true, total, page, pages: Math.ceil(total / limit), data });
});

export const setUserStatus = asyncHandler(async (req, res) => {
  if (req.params.id === String(req.user._id)) throw new AppError('You cannot change your own status', 400);
  const isActive = String(req.body.isActive) === 'true';
  const user = await User.findByIdAndUpdate(req.params.id, { isActive }, { new: true });
  if (!user) throw new AppError('User not found', 404);
  res.json({ success: true, data: user.toSafeObject() });
});

export const listAllApplications = asyncHandler(async (_req, res) => {
  const data = await Application.find()
    .populate('internship', 'title company')
    .populate('student', 'name email')
    .sort({ createdAt: -1 })
    .limit(100)
    .lean();
  res.json({ success: true, data });
});
