import Application, { APPLICATION_STATUSES } from '../models/Application.js';
import Internship from '../models/Internship.js';
import User from '../models/User.js';
import { notifyUser } from '../services/notification.service.js';
import { AppError, asyncHandler } from '../utils/AppError.js';
import { ensureOwner, isPast } from '../utils/helpers.js';

export const applyToInternship = asyncHandler(async (req, res) => {
  const { internshipId, coverLetter = '' } = req.body;
  const internship = await Internship.findById(internshipId);
  if (!internship || !internship.isActive) throw new AppError('Internship not found or closed', 404);
  if (isPast(internship.deadline)) throw new AppError('The application deadline has passed', 400);

  const exists = await Application.exists({ student: req.user._id, internship: internship._id });
  if (exists) throw new AppError('You have already applied to this internship', 409);

  const application = await Application.create({
    student: req.user._id,
    internship: internship._id,
    coverLetter,
    statusHistory: [{ status: 'applied', note: 'Application submitted' }],
  });

  const provider = await User.findById(internship.provider).select('name email');
  notifyUser({
    userId: req.user._id,
    email: req.user.email,
    title: 'Application submitted',
    message: `You applied for ${internship.title} at ${internship.company}.`,
  });
  if (provider) {
    notifyUser({
      userId: provider._id,
      email: provider.email,
      title: 'New applicant',
      message: `${req.user.name} applied for ${internship.title}.`,
    });
  }

  res.status(201).json({ success: true, data: application });
});

export const getMyApplications = asyncHandler(async (req, res) => {
  const data = await Application.find({ student: req.user._id })
    .populate('internship', 'title company location mode stipend deadline')
    .sort({ createdAt: -1 })
    .lean();
  res.json({ success: true, data });
});

export const getInternshipApplications = asyncHandler(async (req, res) => {
  const internship = await Internship.findById(req.params.internshipId);
  if (!internship) throw new AppError('Internship not found', 404);
  ensureOwner(internship, req.user);

  const data = await Application.find({ internship: internship._id })
    .populate('student', 'name email profile.college profile.degree profile.graduationYear profile.skills profile.bio profile.linkedin profile.portfolio')
    .sort({ createdAt: -1 })
    .lean();
  res.json({ success: true, data });
});

export const updateApplicationStatus = asyncHandler(async (req, res) => {
  const application = await Application.findById(req.params.id).populate('internship');
  if (!application || !application.internship) throw new AppError('Application not found', 404);
  ensureOwner(application.internship, req.user);

  if (application.status === 'withdrawn') throw new AppError('Withdrawn applications cannot be updated', 400);

  const { status, note = '' } = req.body;
  if (!APPLICATION_STATUSES.includes(status)) throw new AppError('Invalid status', 400);

  application.status = status;
  application.statusHistory.push({ status, note });
  await application.save();

  const student = await User.findById(application.student).select('name email');
  const label = status.replace(/_/g, ' ');
  if (student) {
    notifyUser({
      userId: student._id,
      email: student.email,
      title: `Application ${label}`,
      message: `Your application for ${application.internship.title} at ${application.internship.company} is now: ${label}.${note ? ` Note: ${note}` : ''}`,
    });
  }

  res.json({ success: true, data: application });
});

export const withdrawApplication = asyncHandler(async (req, res) => {
  const application = await Application.findOne({ _id: req.params.id, student: req.user._id });
  if (!application) throw new AppError('Application not found', 404);
  if (['accepted', 'rejected', 'withdrawn'].includes(application.status)) {
    throw new AppError(`Cannot withdraw an application that is already ${application.status}`, 400);
  }

  application.status = 'withdrawn';
  application.statusHistory.push({ status: 'withdrawn', note: 'Withdrawn by student' });
  await application.save();
  res.json({ success: true, data: application });
});
