import Internship from '../models/Internship.js';
import Application from '../models/Application.js';
import { AppError, asyncHandler } from '../utils/AppError.js';
import { ensureOwner, escapeRegex, normalizeSkills } from '../utils/helpers.js';

const INTERNSHIP_FIELDS = [
  'title', 'description', 'company', 'category', 'location', 'mode', 'duration',
  'stipend', 'openings', 'deadline', 'isActive', 'skills', 'requirements',
];

const SORTS = {
  latest: { createdAt: -1 },
  stipend: { stipend: -1 },
  deadline: { deadline: 1 },
};

const pick = (obj = {}) =>
  Object.fromEntries(Object.entries(obj).filter(([key]) => INTERNSHIP_FIELDS.includes(key)));

export const listInternships = asyncHandler(async (req, res) => {
  const { q, category, location, mode, skill, minStipend, sort = 'latest' } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 12, 1), 50);

  // Only active internships whose deadline has not passed (or has no deadline).
  const filter = { isActive: true, deadline: { $not: { $lt: new Date() } } };
  if (q) filter.$text = { $search: String(q) };
  if (category) filter.category = new RegExp(escapeRegex(category), 'i');
  if (location) filter.location = new RegExp(escapeRegex(location), 'i');
  if (['remote', 'onsite', 'hybrid'].includes(mode)) filter.mode = mode;
  if (skill) filter.skills = String(skill).trim().toLowerCase();
  if (minStipend) filter.stipend = { $gte: Number(minStipend) || 0 };

  const [data, total] = await Promise.all([
    Internship.find(filter)
      .sort(SORTS[sort] || SORTS.latest)
      .skip((page - 1) * limit)
      .limit(limit)
      .lean(),
    Internship.countDocuments(filter),
  ]);

  res.json({ success: true, total, page, pages: Math.ceil(total / limit), count: data.length, data });
});

export const getInternship = asyncHandler(async (req, res) => {
  const internship = await Internship.findById(req.params.id).populate('provider', 'name company').lean();
  if (!internship || !internship.isActive) throw new AppError('Internship not found', 404);
  res.json({ success: true, data: internship });
});

export const listMyInternships = asyncHandler(async (req, res) => {
  const internships = await Internship.find({ provider: req.user._id }).sort({ createdAt: -1 }).lean();
  const counts = await Application.aggregate([
    { $match: { internship: { $in: internships.map((i) => i._id) } } },
    { $group: { _id: '$internship', count: { $sum: 1 } } },
  ]);
  const countMap = new Map(counts.map((c) => [String(c._id), c.count]));
  const data = internships.map((i) => ({ ...i, applicantCount: countMap.get(String(i._id)) || 0 }));
  res.json({ success: true, data });
});

export const createInternship = asyncHandler(async (req, res) => {
  const payload = pick(req.body);
  const internship = await Internship.create({
    ...payload,
    skills: normalizeSkills(payload.skills),
    provider: req.user._id,
    company: payload.company || req.user.company || req.user.name,
  });
  res.status(201).json({ success: true, data: internship });
});

export const updateInternship = asyncHandler(async (req, res) => {
  const internship = await Internship.findById(req.params.id);
  if (!internship) throw new AppError('Internship not found', 404);
  ensureOwner(internship, req.user);

  const data = pick(req.body);
  if (data.skills) data.skills = normalizeSkills(data.skills);
  Object.assign(internship, data);
  await internship.save();
  res.json({ success: true, data: internship });
});

export const deleteInternship = asyncHandler(async (req, res) => {
  const internship = await Internship.findById(req.params.id);
  if (!internship) throw new AppError('Internship not found', 404);
  ensureOwner(internship, req.user);

  await Application.deleteMany({ internship: internship._id });
  await internship.deleteOne();
  res.json({ success: true, message: 'Internship and its applications deleted' });
});
