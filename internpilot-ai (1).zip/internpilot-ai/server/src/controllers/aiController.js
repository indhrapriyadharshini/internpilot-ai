import Internship from '../models/Internship.js';
import User from '../models/User.js';
import { AppError, asyncHandler } from '../utils/AppError.js';
import {
  aiStatus,
  analyzeResume,
  analyzeSkillGap,
  buildInterviewPrep,
  chatReply,
  recommendInternships,
} from '../services/ai.service.js';

const findInternship = async (id) => {
  const internship = await Internship.findById(id).lean();
  if (!internship || !internship.isActive) throw new AppError('Internship not found', 404);
  return internship;
};

export const getStatus = asyncHandler(async (_req, res) => {
  res.json({ success: true, data: aiStatus() });
});

export const getRecommendations = asyncHandler(async (req, res) => {
  const internships = await Internship.find({
    isActive: true,
    deadline: { $not: { $lt: new Date() } },
  }).limit(300).lean();
  const profile = req.user.toObject().profile || {};
  const { mode, data } = await recommendInternships(profile, internships);
  res.json({ success: true, mode, data });
});

export const analyzeResumeText = asyncHandler(async (req, res) => {
  const { resumeText, targetRole = '' } = req.body;
  // Store the resume so it is available later (profile page, interview prep).
  await User.updateOne({ _id: req.user._id }, { 'profile.resumeText': resumeText.slice(0, 20000) });
  const { mode, data } = await analyzeResume(resumeText, targetRole);
  res.json({ success: true, mode, data });
});

export const skillGap = asyncHandler(async (req, res) => {
  const internship = await findInternship(req.body.internshipId);
  const profile = req.user.toObject().profile || {};
  const { mode, data } = await analyzeSkillGap(profile.skills, internship);
  res.json({ success: true, mode, data });
});

export const interviewPrep = asyncHandler(async (req, res) => {
  const internship = await findInternship(req.body.internshipId);
  const profile = req.user.toObject().profile || {};
  const { mode, data } = await buildInterviewPrep(profile, internship);
  res.json({ success: true, mode, data });
});

export const chat = asyncHandler(async (req, res) => {
  const { messages, language = 'en' } = req.body;
  const { mode, reply } = await chatReply(messages, language);
  res.json({ success: true, mode, reply });
});
