import User from '../models/User.js';
import { asyncHandler } from '../utils/AppError.js';
import { normalizeSkills } from '../utils/helpers.js';

const PROFILE_FIELDS = [
  'phone', 'college', 'degree', 'graduationYear', 'skills', 'interests',
  'preferredLocations', 'bio', 'linkedin', 'portfolio',
];

export const getProfile = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user.toSafeObject() });
});

export const updateProfile = asyncHandler(async (req, res) => {
  const updates = {};
  if (req.body.name) updates.name = String(req.body.name).trim();
  if (req.user.role === 'provider' && req.body.company !== undefined) {
    updates.company = String(req.body.company).trim();
  }

  const profile = req.body.profile || {};
  for (const field of PROFILE_FIELDS) {
    if (profile[field] === undefined) continue;
    if (field === 'skills' || field === 'interests') {
      updates[`profile.${field}`] = normalizeSkills(profile[field]);
    } else if (field === 'preferredLocations') {
      updates[`profile.${field}`] = profile[field].map((v) => String(v).trim()).filter(Boolean).slice(0, 20);
    } else {
      updates[`profile.${field}`] = profile[field];
    }
  }

  const user = await User.findByIdAndUpdate(
    req.user._id,
    { $set: updates },
    { new: true, runValidators: true }
  );
  res.json({ success: true, user: user.toSafeObject() });
});
